package SearchEngine;

public class test {

	public static void main(String[] args)  {

		//System.out.println(sedb.getRecordCount("aa"));





	}
}
